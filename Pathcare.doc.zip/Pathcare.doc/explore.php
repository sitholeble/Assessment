<!DOCTYPE html>
<html>
        <body>
			
			<?php
			include("connect.php");    
$sql = "SELECT  b.title,b.author, FROM books b INNER JOIN book_copies c ON
'{$_POST[isbn]}' OR  b.title = '{$_POST[btitle]}' OR b.author ='{$_POST[aname]}'";   
//$subsplittedstring = explode("", $sql);

//if($subsplittedstring==$_POST[btitle] || $subsplittedstring==$_POST[aname] || $subsplittedstring==$_POST[isbn]){
  // $subsplittedstring===$sql;
//}   
$result =$conn->query($sql);      
if ($result->num_rows > 0) 
{      // output data of each row     
	while($row = $result->fetch_assoc())          
		{?>             
	<table border="1">
	<th>Book Title</th><th>Author</th>                 
			<td><?php echo $row["title"]."<br>"?></td>
        <td><?php echo $row["author"]."<br>";?></td>
                               <?php ;     
     } 
 } 
 else 
 {
	echo "0 results"; 
 }?>
 <?php 
 $conn->close(); ?>
</table>
</body> 
</html>
