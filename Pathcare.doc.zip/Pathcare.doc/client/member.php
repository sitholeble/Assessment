
<script language=javascript type='text/javascript' src="jquery.js"> </script>
<script src="../../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style3 {color: #0066FF}
.style4 {
	color: #000000;
	font-weight: bold;
	font-size: 24px;
}
.errstyle {
	color: #FF0000;
	font-size: 12px;
	}
-->
</style>
<style type="text/css">
<!--
.style5 {
	color: #000000;
	font-size: 14px;
}
-->
</style>
 <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
//-->
 </script>
<link href="../../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style7 {
	font-size: 18px;
	color: #000000;
}
.style8 {
	color: #000000;
	font-style: italic;
	font-weight: bold;
	font-size: 18px;
}
-->
</style>
<script language="javascript">
function lettersOnly(evt) {
evt = (evt) ? evt : event;
var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :
((evt.which) ? evt.which : 0));
if ( (charCode < 65 || charCode > 90 ) &&
(charCode < 97 || charCode > 122)) {
if(charCode != 8){
alert("Enter letters only.");
return false;
}

}
return true;
}
</script>
<div class="style4">
  <div align="center"><em>Beneficiary Registration</em></div>
</div>
<form action="" method="post" name="" onsubmit="MM_validateForm('name','','R','surname','','R','id_first_digit','','RisNum','id_second_digit','','RisNum','id_forth_digit','','RisNum');return document.MM_returnValue" target="my-iframe">

   
  <table width="80%" border="0" bgcolor='#003366'align="center" style="border-top:3px solid #000000;">
  
    
    <tr>
      <td>Name</td>
      <td>
        <input name="name" type="text" id="name" onkeypress="return lettersOnly(event)" />       </td>
        </tr>
          <tr>
            <td width="267"> Surname</td>
            <td width="287">
            <input name="surname" type="text" id="surname" onkeypress="return lettersOnly(event)"  />              </td>
    </tr>
          
          
<tr>
            <td>National ID Number</td>
            
            <td>
            <input name="id_first_digit" type="text" id="id_first_digit" size="2" maxlength="2"  />-<input name=" id_second_digit" type="text" maxlength="8" id="id_second_digit" size="9" />-<select name="id_third_letters"><option>A</option><option>B</option><option>C</option><option>D</option><option>E</option><option>F</option><option>G</option><option>H</option><option>I</option><option>J</option><option>K</option><option>L</option><option>M</option><option>N</option><option>O</option><option>P</option><option>Q</option><option>R</option><option>S</option><option>T</option><option>U</option><option>V</option><option>W</option><option>X</option><option>Y</option><option>X</option></select>
            -<input name="id_forth_digit" type="text" id="id_forth_digit" size="2" maxlength="2"  /></td>
          </tr>
   
   
<tr>
            <td></td>
            <td>
              <input name="submit" type="Submit" id="submit" value="Save"  />            </td>
          </tr>
    </table>
  
</form>

<?php
  if(isset($_POST['submit'])){
   include "opendb.php";
   	  $resul = mysql_query("SELECT * FROM users where username='$_SESSION[username]'") or die (mysql_error());
	
while($rows = mysql_fetch_array($resul)){
$plan= $rows['dept'];}
$res = mysql_query("SELECT * FROM plan where title='$plan'") or die (mysql_error());
	
while($rows = mysql_fetch_array($res)){
$number = $rows['people'];}
   
   $q1 = mysql_query("select * from member where user = '$_SESSION[username]'");
   $rwq = mysql_num_rows($q1);
   if($rwq >= $number){
   ?>
  <script language="javascript">
 alert("Plan Allows Only <?php echo "$number"; ?> Beneficiaries");
 location = 'index.php?page=ben.php'
  </script>
  <?php
  exit;
   }
   $date = date('m/d/Y');
   $name = $_POST['name'];
   $surname = $_POST['surname'];
  
   $id_no = $_POST['id_first_digit']."-".$_POST['id_second_digit']."-".$_POST['id_third_letters']."-".$_POST['id_forth_digit'];
  
   $rs1 = mysql_query("select * from member where idnumber = '$id_no'");
   $rw = mysql_num_rows($rs1);
   if($rw == 1){
   ?>
  <script language="javascript">
 alert("beneficiary already added");
 location = 'index.php?page=member.php'
  </script>
  <?php
  exit;
   }
   
   else{
 $rs = mysql_query("insert into member(user,namem,surnamem,idnumberm) values ('$_SESSION[username]','$_POST[name]','$_POST[surname]','$id_no')") or die(mysql_error());

 
  if($rs){
  ?>
  <script language="javascript">
 alert(" successfully created");
 location = 'index.php?page=member.php'
  </script>
  <?php
  
  }
  else
  {
  echo "problem occured";
  }
  }
  }
?>

<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {minChars:8, validateOn:["blur", "change"]});
//-->
</script>
<iframe name="my-iframe" width="0" height="0"></iframe>