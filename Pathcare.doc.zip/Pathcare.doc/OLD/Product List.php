<?php 
error_reporting(0);
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title></title>
<meta name="" content="" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="css/defaulf.css" rel="stylesheet" type="text/css" />
<script src="../../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="../../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: 12px}
.style2 {font-size: 14px}
.style4 {font-size: 12px; font-weight: bold; }
-->
</style>
<script type="text/javascript">
<!--
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
//-->
</script>
</head>
<body>
<div align="center">
	<div class="main_div">
		<div class="main">
			<div class="main_site">
			  <div class="header">
				 
					<form action="" method="post" onsubmit="MM_validateForm('id1','','RisNum','id2','','RisNum','id4','','RisNum');return document.MM_returnValue" >
					  <table width="100%" border="0" >  <p>Product List<br />
					   
					
					<tr>
                              
                <input name="id2" type="text" id="id2" size="8" maxlength="8" />
                
                <select name="id3" id="id3">
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                  <option value="E">E</option>
                  <option value="F">F</option>
                  <option value="G">G</option>
                  <option value="H">H</option>
                  <option value="I">I</option>
                  <option value="J">J</option>
                  
                </select>
                -
                </td> 
                        </tr><input name="button" type="Submit" id="button" value="Search"  />  
					
				</table></form>
				  <br />
</h1>
					
			    <table width="100%" border="0" >
                   
<tr> 
                                  <td bgcolor="#CCCCCC" width="119"><font color="#0033CC">Title</font></td>
                        <td bgcolor="#CCCCCC" width="125"><font color="#0033CC">Description</font></td>
                                                <td bgcolor="#CCCCCC" width="222"><font color="#0033CC">Product ID N#</font></td>

					    <td bgcolor="#CCCCCC" width="123"><font color="#0033CC">Price</font></td>
                        <td bgcolor="#CCCCCC" width="222"><font color="#0033CC">Image</font></td>
   								  							 
                                  
						
              <?php include "opendb.php";
if(isset($_POST['button']))
{
		
		if( strlen($_POST["id1"]) < 2)
	{
		?>
              <script language="javascript">
						  alert("Invalid input on 1st Product ID input");
						  </script>
                          <?php
						  exit();
	}
	if( strlen($_POST["id2"]) < 8)
	{
		?>
              <script language="javascript">
						  alert("Invalid input on 2nd Product ID input");
						  </script>
                          <?php
						  exit();
	}
	
	$productid=$_POST["id1"]."-".$_POST["id2"];	
	//$rs=mysql_query("select * from apply where idnumber='$productid'") or die(mysql_error());
	
	$result=mysql_query("select * from client_order where idnumber='$productid' ") ;
$rows = mysql_num_rows($result);
	if($rows==0)
 


?>        </tr></table>      

							</div>
			</div>
	  </div>
  </div>

	
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "date", {validateOn:["change"], format:"dd.mm.yyyy"});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "date", {validateOn:["change"], format:"dd.mm.yyyy", hint:"dd.mm.yyyy"});
//-->
</script>
</body>
</html>