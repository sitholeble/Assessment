<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body> <table width="100%" border="0" bgcolor='#006699'>
					  <tr> 
                                  <td width="119"><font color="#0033CC">Name</font></td>
                        <td  width="125"><font color="#0033CC">Surname</font></td>
                                                <td width="222"><font color="#0033CC">Id N#</font></td>

					    <td width="123"><font color="#0033CC">Type of Plan</font></td>
							<td  width="123"><font color="#0033CC">Date Applied</font></td>
								 
                                    
						
                      <?php
					  error_reporting(0);
	 
	  include 'opendb.php';
	 
	   $nguva=date('m/d/Y');
	echo $date;
	  $result ="";
	 $result = mysql_query("SELECT * FROM users ")or die(mysql_query());
		 
	   if(!$result)
{
	die( "\n\ncould'nt send the query because".mysql_error());
	exit;
}
	
  while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	  	  
{

echo "<tr><td>{$row['name']}</td><td>{$row['surname']}</td><td>{$row['idnumber']}</td><td>{$row['dept']}</td><td>{$row['date']}</td></tr>";
}

?>        </tr></table>     

</body>
</html>
