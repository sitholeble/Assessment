<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p> The Six Pack Plan</p>
<p>
What is Six Pack?
The Six Pack Plan is a funeral package designed with Zimbsabwean culture and values in mind. It is our practice that we take care of our extended family. With the Six Pack Plan you can cover your spouse, parents and in-laws under one policy. YOU can make your own six pack by nominating any five people to be covered..</p>
</br>

<p> Individual Policies</p>
<p>
Funeral Assurance policies are the best tool to manage the financial burden of a funeral. We have the Executive, Classic and Budget plans under the individual range, all designed to allow you to choose a package of benefits to suit your needs and pocket size. All of them will cover the spouse and children under twenty three years of age are covered free of charge.</p>
</body>
</html>
