<?php
//error_reporting(0);
//include ('aut.php');
//$username=$_SESSION['username'] ;
 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xht   ml">
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<style type="text/css">
.underlinemenu{
font-weight: bold;
width: 100%;
}

.underlinemenu ul{
padding: 6px 0 7px 0; /*6px should equal top padding of "ul li a" below, 7px should equal bottom padding + bottom border of "ul li a" below*/
margin: 0;
text-align: right; //set value to "left", "center", or "right"*/
}

.underlinemenu ul li{
display: inline;
}

.underlinemenu ul li a{
color: #494949;
padding: 6px 3px 4px 3px; /*top padding is 6px, bottom padding is 4px*/
margin-right: 20px; /*spacing between each menu link*/
text-decoration: none;
border-bottom: 3px solid gray; /*bottom border is 3px*/
}

.underlinemenu ul li a:hover, .underlinemenu ul li a.selected{
border-bottom-color: black;
}

</style>

	<link rel="stylesheet" type="text/css" href="file:///C|/wamp/WRL/admin/css/ui.css">
	<link rel="styleSheet" type="text/css" href="file:///C|/wamp/WRL/admin/css/main-print.css" media="print">	
	<link rel="styleSheet" type="text/css" href="file:///C|/wamp/WRL/admin/css/load.css">
</html>

<html xmlns="http://www.w3.org/1999/xhtml">
<body>
<!--<p align="center"><font size="5"><strong>Edit User Department List</strong></font></p>
-->
<form action="" method="post" name="qualification_form" onSubmit="MM_validateForm('age','','RisNum');return document.MM_returnValue">
<table width="100%" border="0" align="center" style="border-bottom:3px solid #000000;">
 <div align="center"><span class="style7">Select the policy type to start selecting<br />
<a href="index.php?page=settings.php">View All Applicants</a></span></div>
 
      <tr>
        <td><div align="center"><span class="style7">Select Type</span></div></td>
       
      </tr>
      
    </table> 
    <div class="errstyle" id="errr"></div>
    <div class="errstyle" id="err"></div>
 <table width="100%">
</table>



  
  <table width="100%" align="center"><tr>
            <td>Plan Type</td>
            <td>
             <select name='dept' id ='dept'>
<option value="0">--- Select type ---</option>
<option value="six pack">six pack</option>
<option value="individual">individual</option>


</select            ></td>
          </tr>
          
</td></tr>

<tr><td colspan="2"  align="center"><input type="submit" name="submit" size="30"  value="SELECT"/></td>
</tr>
</table></form>

  <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor='#003399'>
<p align="center">Applications<br />
  <tr>
  
  <!-- <td width="139"><strong><font size="1" face="Arial, Helvetica, sans-serif">RISK</font></strong></td>
    <td width="152"><strong><font size="1" face="Arial, Helvetica, sans-serif">LOCATION</font></strong></td>-->
   
    
    <td width="139"><strong><font size="1" face="Arial, Helvetica, sans-serif">Name</font></strong></td>
    <td width="152"><strong><font size="1" face="Arial, Helvetica, sans-serif">Surname</font></strong></td>
    <td width="152"><strong><font size="1" face="Arial, Helvetica, sans-serif">Id N#</font></strong></td>
     <td width="152"><strong><font size="1" face="Arial, Helvetica, sans-serif">Email</font></strong></td>
    <td width="152"><strong><font size="1" face="Arial, Helvetica, sans-serif">Sex</font></strong></td>
        <td width="139"><strong><font size="1" face="Arial, Helvetica, sans-serif">Plan Type</font></strong></td>
 <td width="139" ><strong><font size="1" face="Arial, Helvetica, sans-serif">Username</font></strong></td>

     <td width="123"><font size="1" face="Arial, Helvetica, sans-serif"><strong>Date</strong></font></td>
     <td width="139"><strong><font size="1" face="Arial, Helvetica, sans-serif">Approve</font></strong></td>
     <td width="139"><strong><font size="1" face="Arial, Helvetica, sans-serif">Disapprove</font></strong></td>
    
 
  </tr>
 
  <?php
include 'opendb.php';

		if (isset($_POST['submit'])){
$nguva=date('m/d/Y');
//$limit=$_POST['number'];
//$rs1=mysql_query("select * from age where age.grade='$_POST[grade]' ") or die(mysql_error());
//while($row = mysql_fetch_array($rs1)){
		//mysql_query("update apply set status = 'considering' where appid = '$row[appid]'");
		//$age = $row['age'];
		//$age1 = $row['age1'];
		//$limit = $row['limit'];}
//echo $age; exit;
$rs=mysql_query("select * from users where status='pending' and dept='$_POST[dept]'") or die(mysql_error());
$rows = mysql_num_rows($rs);
	if($rows==0)
 {
 	echo("<SCRIPT LANGUAGE='JavaScript'> window.alert('No Applications In This in this type of policy plan')
		 location = 'index.php?page=application.php'
		 	</SCRIPT>");  
			exit;

 }
while($row = mysql_fetch_array($rs)){
		//mysql_query("update apply set status = 'considering' where appid = '$row[appid]'");
		$nameg = $row['name'];
		$idn = $row['surname'];
		$name = $row['idnumber'];
		$name1 = $row['idnumber'];
		$surname = $row['sex'];
		$idnum = $row['dept'];
		$risk = $row['username'];/*
		$location = $row['location'];
		$comment = $row['comment'];*/
		$date = $row['date'];
		$id= $row['id'];
	?>
<tr>
    <td colspan="9">&nbsp;</td>
  </tr>

  <tr bgcolor="#">
  
    
 
    <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $nameg; ?></font></td>
   
   
    <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $idn; ?></font></td>
     <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $name; ?></font></td>
     <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $name1; ?></font></td>
    <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $surname; ?></font></td>
    <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $idnum; ?></font></td>
       <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $risk; ?></font></td>
    <td><font size="1" face="Arial, Helvetica, sans-serif"><?php echo $date; ?></font></td>
    
     
    
    <!--<td><font size="1" face="Arial, Helvetica, sans-serif"><a href="index.php?page=edit.php&id=">[RESPOND NOW]</a></font></td>
   
    
  </tr>-->
  <?php
	 

	 	  



//$song = "../upload/".$row['upload'];	
/*echo "<td ><a href='$song'>Download</a></td></tr>";
*/

?> 
<td><font size="1" face="Arial, Helvetica, sans-serif"><a href="index.php?page=approve.php&id=<?php echo $id; ?>">[APPROVE]</a></font></td><td><font size="1" face="Arial, Helvetica, sans-serif"><a href="index.php?page=disapprove.php&id=<?php echo $id; ?>">[DISAPPROVE]</a></font></td></tr>
<?php } 
/* $rz = mysql_query("select * from apply where status = 'pending'");
 while($rw = mysql_fetch_array($rz))
 {
 mysql_query("update apply set status = 'waiting' where id = '$rz[appiid]'");
 }*/}
?>
<!-- <a href="../staff/meeting/1362996579"-->

</table>


</body>
</html>

