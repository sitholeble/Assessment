<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
  
   include "opendb.php";
    $nguva=date('m/d/Y');
	
  $rs = mysql_query("UPDATE users set status='approved' where id = '$_GET[id]'");
 
  if($rs){
  ?>
  <script language="javascript">
 alert("Approval successfully updated");
		location=' index.php?page=application.php'
  </script>
  <?php
  
  }
  else
  {
  echo "problem occured";
  }
  

?>
</body>
</html>
