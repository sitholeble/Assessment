-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 17, 2018 at 11:40 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

--
-- Database: `client_order_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_details`
--

CREATE TABLE `client_details` (
  `Client_ID` int(6) NOT NULL auto_increment,
  `Name` varchar(20) NOT NULL,
  `Surname` varchar(20) NOT NULL,
  `Address Type` varchar(11) default NULL,
  `Street Address` varchar(50) default NULL,
  `Surburb` varchar(15) default NULL,
  `City/Town` varchar(20) default NULL,
  `Postal Code` int(4) default NULL,
  PRIMARY KEY  (`Client_ID`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

--
-- Dumping data for table `client_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `Product_ID` int(11) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `Description` varchar(6) NOT NULL,
  `Price` varchar(12) NOT NULL,
  `Image` varchar(20) default NULL,
  UNIQUE KEY `Product_ID` (`Product_ID`)
) TYPE=MyISAM;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`Product_ID`, `Title`, `Description`, `Price`, `Image`) VALUES
(2147483647, 'Naks', '50g', 'R0.35', NULL),
(5555555, 'Sweets', '2kg', 'R33', NULL),
(6666666, 'MARGARINE', '500G', 'R14.75', NULL),
(7777777, 'BREAD', '750G', 'R9.99', NULL),
(222222222, 'BEEF', '5.5KG', 'R363.56', NULL),
(3333333, 'SPINACH', 'BUNCH', 'R10', NULL),
(444444444, 'RICE', '2KG', 'R23.99', NULL),
(88888888, 'EXERCISE BOOKS', '10', 'R15', NULL),
(99999999, 'CHEESE', '75G', 'R6.43', NULL),
(1111111111, 'COOKING OIL', '3.5L', 'R44.80', NULL);
